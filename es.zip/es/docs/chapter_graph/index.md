# Grafo

![Grafo](../assets/covers/chapter_graph.jpg)

!!! abstract

    En el viaje de la vida, cada uno de nosotros es un nodo, conectado por innumerables aristas invisibles.
    
    Cada encuentro y despedida deja una huella única en este vasto grafo de la vida.

# Divide y vencerás

![Divide y vencerás](../assets/covers/chapter_divide_and_conquer.jpg)

!!! abstract

    Los problemas difíciles se descomponen capa por capa, y cada descomposición los hace más simples.

    Divide y vencerás revela una verdad profunda: comienza con la simplicidad, y la complejidad se disuelve.

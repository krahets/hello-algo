# Pila y cola

![Pila y cola](../assets/covers/chapter_stack_and_queue.jpg)

!!! abstract

    Una pila es como gatos colocados uno encima del otro, mientras que una cola es como gatos alineados uno por uno.
    
    Representan las relaciones lógicas de Último en Entrar, Primero en Salir (LIFO) y Primero en Entrar, Primero en Salir (FIFO), respectivamente.

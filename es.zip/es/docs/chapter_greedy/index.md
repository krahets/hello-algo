# Codicioso

![Codicioso](../assets/covers/chapter_greedy.jpg)

!!! abstract

    Los girasoles giran hacia el sol, buscando siempre el mayor crecimiento posible para sí mismos.

    La estrategia codiciosa guía hacia la mejor respuesta paso a paso a través de rondas de elecciones simples.

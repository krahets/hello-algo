# Tabla hash

![Tabla hash](../assets/covers/chapter_hashing.jpg)

!!! abstract

    En el mundo de la computación, una tabla hash es similar a un bibliotecario inteligente.
    
    Sabe cómo calcular números de índice, lo que permite una rápida recuperación del libro deseado.

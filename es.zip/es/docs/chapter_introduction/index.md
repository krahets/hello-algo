# Encuentro con los algoritmos

![Encuentro con los algoritmos](../assets/covers/chapter_introduction.jpg)

!!! abstract

    Una grácil doncella baila, entrelazada con los datos, su falda se mece al son de la melodía de los algoritmos.
   
    Te invita a un baile, sigue sus pasos y entra en el mundo de los algoritmos lleno de lógica y belleza.

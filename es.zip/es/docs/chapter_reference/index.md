---
icon: material/bookshelf
---

# Referencias

[1] Thomas H. Cormen, et al. Introduction to Algorithms (3rd Edition).

[2] Aditya Bhargava. Grokking Algorithms: An Illustrated Guide for Programmers and Other Curious People (1st Edition).

[3] Robert Sedgewick, et al. Algorithms (4th Edition).

[4] Yan Weimin. Data Structures (C Language Version).

[5] Deng Junhui. Data Structures (C++ Language Version, Third Edition).

[6] Mark Allen Weiss, translated by Chen Yue. Data Structures and Algorithm Analysis in Java (Third Edition).

[7] Cheng Jie. Speaking of Data Structures.

[8] Wang Zheng. The Beauty of Data Structures and Algorithms.

[9] Gayle Laakmann McDowell. Cracking the Coding Interview: 189 Programming Questions and Solutions (6th Edition).

[10] Aston Zhang, et al. Dive into Deep Learning.

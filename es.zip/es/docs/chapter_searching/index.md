# Búsqueda

![Búsqueda](../assets/covers/chapter_searching.jpg)

!!! abstract

    La búsqueda es una aventura hacia lo desconocido; donde es posible que tengamos que recorrer cada rincón de un espacio misterioso, o quizás localicemos rápidamente nuestro objetivo.
    
    En este viaje de descubrimiento, cada exploración puede terminar con una respuesta inesperada.

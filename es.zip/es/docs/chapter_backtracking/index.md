# Backtracking

![Backtracking](../assets/covers/chapter_backtracking.jpg)

!!! abstract

    Como exploradores en un laberinto, podemos encontrar obstáculos en nuestro camino.

    El poder del backtracking nos permite empezar de nuevo, seguir intentándolo y, finalmente, encontrar la salida que nos lleva a la luz.
